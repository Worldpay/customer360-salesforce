(function () {
  var list = document.getElementById('needs-action-list');
  if (!list || typeof NEEDS_ACTION_ITEMS === 'undefined') return;

  list.innerHTML = NEEDS_ACTION_ITEMS.map(function (item) {
    return (
      '<div class="a">' +
        '<span class="sev ' + item.severity + '">' + item.severityLabel + '</span>' +
        '<div class="a-txt">' +
          '<b>' + item.heading + '</b>' +
          '<div class="m">' + item.body + '</div>' +
          '<div class="meta">' + item.meta + '</div>' +
        '</div>' +
        '<button class="' + item.buttonClass + '" data-open-account="' + item.accountName + '">' + item.buttonLabel + '</button>' +
      '</div>'
    );
  }).join('');
})();
