import { LightningElement, api } from 'lwc';
import { MATERIAL_BANNER } from 'c/c360MockData_ex_04';

export default class C360MaterialBanner_ex_04 extends LightningElement {
    @api message = MATERIAL_BANNER.message;
}
