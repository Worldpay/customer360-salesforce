# Customer 360 — Experiment 04

**Working copy** for the next experiment — duplicated from [`Experiment 02`](../Experiment%2002/). Experiment 01 remains frozen as the decomposed hybrid reference; Experiment 02 remains the completed org-overlay baseline.

Template-aligned, **LWC-only org overlay** build.

## Naming convention (Experiment 04)

All deployable artefacts use the `_ex_04` suffix to avoid collisions with other experiments or org components:

- LWC bundles: `c360Dashboard_ex_04`, `c360KpiTile_ex_04`, …
- Manifest: `manifest/package-lwc_ex_04.xml`
- Docs: `PLAN_SUMMARY_ex_04.md`, `ORG_WIRING_RUNBOOK_ex_04.md`, `HANDOFF_CHECKLIST_ex_04.md`
- SFDX project: `c360_lwc_experiment_ex_04`

## What this is

- **Monolithic hub:** `c360Dashboard_ex_04` (Overview, Alert Centre, Cross-Sell, Churn, Pathways, inline Account)
- **Wireframe screens:** `c360AlertCentre_ex_04`, `c360AlertDetail_ex_04`
- **Record Page bootstrap:** `c360Account_ex_04` (leadSpotlight pattern)
- **Shared children:** `c360KpiTile_ex_04`, `c360SignalList_ex_04`, `c360ExportModal_ex_04`
- **Mock data:** `c360MockData_ex_04` (sandbox UAT until Apex wired)

## What this is NOT

Do **not** deploy from this folder:

- `applications/` — use org Lightning App
- `flexipages/` — swap component in existing App Builder pages
- `tabs/` — org tabs already configured
- `classes/` — merge stubs into existing Apex (see `classes-stubs_ex_04/`)

## Quick deploy (LWC only)

```bash
cd "08. Experiments/Experiment 04"
sf project deploy start --manifest manifest/package-lwc_ex_04.xml
```

Then follow [ORG_WIRING_RUNBOOK_ex_04.md](ORG_WIRING_RUNBOOK_ex_04.md) to wire `c360Dashboard_ex_04` on the existing App Page.

## Modular prototypes (HTML)

Browser-previewable HTML modules live under [`prototypes/html/`](prototypes/html/). No Salesforce CLI required — double-click any `preview.html` to open in Chrome or Edge.

**Start here:** [`prototypes/html/assembly/overview-page.html`](prototypes/html/assembly/overview-page.html) — full Overview page composed from modules.

### Folder conventions

```
prototypes/
├── MODULE_REGISTRY_ex_04.md     # HTML → LWC status tracker
└── html/
    ├── shared/                  # tokens, shell, mock data
    ├── modules/<name>/          # MODULE_SPEC.md, fragment.*, preview.html
    └── assembly/                # overview-page.html
```

Each module folder contains:

- `MODULE_SPEC.md` — LWC conversion contract (`@api`, events, mock DTO)
- `fragment.html` — panel markup only (canonical for LWC conversion)
- `fragment.css` / `fragment.js` — scoped styles and interactions
- `preview.html` — self-contained browser preview with shell chrome

### Module list

| Priority | Module | Preview |
|----------|--------|---------|
| P0 | kpi-strip, needs-action, portfolio-health, signal-list | See [MODULE_REGISTRY_ex_04.md](prototypes/MODULE_REGISTRY_ex_04.md) |
| P1 | accounts-table, material-banner, alert-centre | |
| P2 | cross-sell-table, churn-table, pathways-table | |

Mock data in `prototypes/html/shared/mock-data.js` mirrors `c360MockData_ex_04.js`.

## Authority hierarchy

1. `07. Knowledge for C360/salesforce-hard-constraints.md`
2. `07. Knowledge for C360/requirements-registry.md`
3. `10. Wireframe/` → IA and screen inventory
4. `09. Design system/` → visual tokens (supersedes prototype CSS)
5. `06. Output templates/` → LWC code patterns
6. `04 C360 Prototype` → content fallback

## Key trade-offs documented

| Topic | Exp 04 choice | Alternative |
|-------|---------------|-------------|
| Hub architecture | Monolithic `c360Dashboard_ex_04` | Exp 01 decomposed `c360App` |
| Account drill-down | Inline view (Shift+click → Record Page) | Always NavigationMixin (R14) |
| Alert Centre | Embedded in dashboard nav | Separate App Page tab |
| Data | Mock in `c360MockData_ex_04.js` | `@wire` to org Apex |
| apiVersion | 62.0 | Template 67.0 |

## Bundle inventory

| LWC | Exposed | App Builder label | Targets |
|-----|---------|-------------------|---------|
| `c360Dashboard_ex_04` | Yes | C360 Dashboard (ex_04) | App Page, Home Page |
| `c360MaterialBanner_ex_04` | Yes | C360 Material Banner (ex_04) | App Page, Home Page |
| `c360KpiStrip_ex_04` | Yes | C360 KPI Strip (ex_04) | App Page, Home Page |
| `c360NeedsAction_ex_04` | Yes | C360 Needs Action (ex_04) | App Page, Home Page |
| `c360PortfolioHealth_ex_04` | Yes | C360 Portfolio Health (ex_04) | App Page, Home Page |
| `c360MySignals_ex_04` | Yes | C360 My Signals (ex_04) | App Page, Home Page |
| `c360AccountsTable_ex_04` | Yes | C360 Accounts Table (ex_04) | App Page, Home Page |
| `c360AlertCentre_ex_04` | Yes | C360 Alert Centre (ex_04) | App Page, Home Page |
| `c360CrossSellTable_ex_04` | Yes | C360 Cross-Sell Table (ex_04) | App Page, Home Page |
| `c360ChurnTable_ex_04` | Yes | C360 Churn Table (ex_04) | App Page, Home Page |
| `c360PathwaysTable_ex_04` | Yes | C360 Pathways Table (ex_04) | App Page, Home Page |
| `c360AlertDetail_ex_04` | Yes | C360 Alert Detail (ex_04) | App Page, Home Page |
| `c360Account_ex_04` | Yes | C360 Account (ex_04) | Account Record Page |
| `c360KpiTile_ex_04` | No | — | Child only (used by KPI strip) |
| `c360SignalList_ex_04` | No | — | Child only (used by My Signals) |
| `c360ExportModal_ex_04` | No | — | Child only |
| `c360MockData_ex_04` | No | — | Shared module |

## Full plan and gap analysis

See [PLAN_SUMMARY_ex_04.md](PLAN_SUMMARY_ex_04.md) for assumptions, open questions (by topic), and design-input gap analysis.

## Relationship to Experiment 01

| | Experiment 01 | Experiment 02 | **Experiment 04** |
|---|---|---|---|
| Hub | `c360App` + view LWCs | `c360Dashboard` monolith | **Same as Exp 02 (renamed `_ex_04`)** |
| Metadata | Includes app/flexipage/tab | LWC only | **LWC only** |
| Status | Complete reference | Complete baseline | **Active — next experiment** |

**Only one hub component should be active on the org flexipage.**
