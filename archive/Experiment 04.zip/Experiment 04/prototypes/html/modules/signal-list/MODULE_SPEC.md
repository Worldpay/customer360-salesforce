# c360MySignals_ex_04

## Requirement
R03 — signals list with action and dismiss (App Builder tile)

## App Builder
- Region: Main
- Design attributes: title (string)

## @api (LWC)
- title: string = "My signals"

## Events (bubbling)
- showtoast: { message: string }

## Child component
- `c360SignalList_ex_04` (not exposed — list rows only)

## Mock DTO
`SIGNALS` in `c360MockData_ex_04.js`
