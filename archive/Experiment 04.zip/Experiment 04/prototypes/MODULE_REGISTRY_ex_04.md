# MODULE_REGISTRY_ex_04

Inventory of HTML prototype modules and their LWC conversion status for Experiment 04.

**Last updated:** 2026-09-08

## Status legend

| Column | Values |
|--------|--------|
| Spec | `done` = MODULE_SPEC.md written |
| HTML | `done` = fragment + preview complete |
| UAT | Stakeholder browser review (blank until run) |
| LWC | Target bundle name; `pending` until converted |
| Deployed | Sandbox flexipage wired (blank until done) |

## Module inventory

| HTML module | Priority | Spec | HTML | UAT | LWC target | Deployed |
|-------------|----------|------|------|-----|------------|----------|
| `kpi-strip` | P0 | done | done | | `c360KpiStrip_ex_04` | done |
| `needs-action` | P0 | done | done | | `c360NeedsAction_ex_04` | done |
| `portfolio-health` | P0 | done | done | | `c360PortfolioHealth_ex_04` | done |
| `signal-list` | P0 | done | done | | `c360MySignals_ex_04` | |
| `accounts-table` | P1 | done | done | | `c360AccountsTable_ex_04` | done |
| `material-banner` | P1 | done | done | | `c360MaterialBanner_ex_04` | done |
| `alert-centre` | P1 | done | done | | `c360AlertCentre_ex_04` | done |
| `cross-sell-table` | P2 | done | done | | `c360CrossSellTable_ex_04` | done |
| `churn-table` | P2 | done | done | | `c360ChurnTable_ex_04` | done |
| `pathways-table` | P2 | done | done | | `c360PathwaysTable_ex_04` | done |

## Preview paths

Open in a browser (double-click, no Salesforce CLI):

| Module | Preview file |
|--------|--------------|
| Overview (assembly) | [`html/assembly/overview-page.html`](html/assembly/overview-page.html) |
| KPI strip | [`html/modules/kpi-strip/preview.html`](html/modules/kpi-strip/preview.html) |
| Needs action | [`html/modules/needs-action/preview.html`](html/modules/needs-action/preview.html) |
| Portfolio health | [`html/modules/portfolio-health/preview.html`](html/modules/portfolio-health/preview.html) |
| Signal list | [`html/modules/signal-list/preview.html`](html/modules/signal-list/preview.html) |
| Accounts table | [`html/modules/accounts-table/preview.html`](html/modules/accounts-table/preview.html) |
| Material banner | [`html/modules/material-banner/preview.html`](html/modules/material-banner/preview.html) |
| Alert centre | [`html/modules/alert-centre/preview.html`](html/modules/alert-centre/preview.html) |
| Cross-sell table | [`html/modules/cross-sell-table/preview.html`](html/modules/cross-sell-table/preview.html) |
| Churn table | [`html/modules/churn-table/preview.html`](html/modules/churn-table/preview.html) |
| Pathways table | [`html/modules/pathways-table/preview.html`](html/modules/pathways-table/preview.html) |

## Shared assets

- [`html/shared/tokens.css`](html/shared/tokens.css) — design tokens
- [`html/shared/shell.css`](html/shared/shell.css) — global header and nav
- [`html/shared/module-base.css`](html/shared/module-base.css) — panel primitives
- [`html/shared/mock-data.js`](html/shared/mock-data.js) — mock DTOs (mirrors `c360MockData_ex_04.js`)
- [`html/shared/shell.js`](html/shared/shell.js) — toast and delegated click handlers

## Next steps

1. Compose modules on flexipage via App Builder (see [ORG_WIRING_RUNBOOK_ex_04.md](../ORG_WIRING_RUNBOOK_ex_04.md) Step 2b)
2. Extract `c360Shell_ex_04` from dashboard chrome (optional)
3. Wire mock data to Apex per `classes-stubs_ex_04/APEX_MERGE_GUIDE_ex_04.md`
