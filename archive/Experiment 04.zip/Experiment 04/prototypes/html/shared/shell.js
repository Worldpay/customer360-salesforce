(function () {
  var toastEl = document.getElementById('toast');
  var toastTimer;

  window.c360Toast = function (msg) {
    if (!toastEl) return;
    toastEl.innerHTML = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toastEl.classList.remove('show');
    }, 3200);
  };

  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-toast]');
    if (el) {
      window.c360Toast(el.getAttribute('data-toast'));
      return;
    }

    var acct = e.target.closest('[data-open-account]');
    if (acct) {
      window.c360Toast('Open account: <b>' + acct.getAttribute('data-open-account') + '</b> (preview only)');
      return;
    }

    var openAlert = e.target.closest('[data-open-alert]');
    if (openAlert) {
      window.c360Toast('Open alert: <b>' + openAlert.getAttribute('data-open-alert') + '</b> (preview only)');
      return;
    }

    var initiate = e.target.closest('[data-initiate]');
    if (initiate) {
      window.c360Toast('Pathway initiated: <b>' + initiate.getAttribute('data-initiate') + '</b>');
    }
  });
})();
