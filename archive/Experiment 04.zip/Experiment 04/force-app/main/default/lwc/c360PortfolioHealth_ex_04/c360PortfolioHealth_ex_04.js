import { LightningElement, api } from 'lwc';
import { PORTFOLIO_HEALTH } from 'c/c360MockData_ex_04';

export default class C360PortfolioHealth_ex_04 extends LightningElement {
    @api title = 'Portfolio health';

    get health() {
        return PORTFOLIO_HEALTH;
    }

    get pipelineRows() {
        return PORTFOLIO_HEALTH.pipeline.map((row) => ({
            ...row,
            barStyle: `width:${row.width}`
        }));
    }
}
