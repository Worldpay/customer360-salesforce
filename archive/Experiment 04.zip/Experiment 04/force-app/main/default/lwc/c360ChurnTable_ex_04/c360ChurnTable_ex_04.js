import { LightningElement, api } from 'lwc';
import { CHURN_ROWS } from 'c/c360MockData_ex_04';

export default class C360ChurnTable_ex_04 extends LightningElement {
    @api title = 'Accounts by churn risk';

    get rows() {
        return CHURN_ROWS.map((row) => ({
            ...row,
            riskPillClass: row.riskClass
        }));
    }

    handleOpenAccount(event) {
        const accountName = event.currentTarget.dataset.account;
        this.dispatchEvent(new CustomEvent('accountopen', {
            detail: { accountName },
            bubbles: true,
            composed: true
        }));
    }
}
