import { LightningElement, api } from 'lwc';
import { ACCOUNTS } from 'c/c360MockData_ex_04';

export default class C360AccountsTable_ex_04 extends LightningElement {
    @api title = 'My accounts';
    @api subtitle = 'Top movers';
    @api maxRows = 5;
    @api provenance = 'Snowflake → Analytics Engine → Salesforce | 15-min refresh';

    get rows() {
        const limit = Number(this.maxRows) || 5;
        const source = ACCOUNTS.slice(0, limit);
        return source.map((account) => ({
            ...account,
            healthPillClass: account.healthClass,
            riskPillClass: account.riskClass,
            deltaClass: account.healthDelta.startsWith('-') ? 'negative' : 'up'
        }));
    }

    handleOpenAccount(event) {
        const accountName = event.currentTarget.dataset.account;
        this.dispatchEvent(new CustomEvent('accountopen', {
            detail: { accountName },
            bubbles: true,
            composed: true
        }));
    }
}
