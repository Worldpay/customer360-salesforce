import { LightningElement, api } from 'lwc';
import { PATHWAYS } from 'c/c360MockData_ex_04';

export default class C360PathwaysTable_ex_04 extends LightningElement {
    @api title = 'In-progress pathways';
    pathwayScope = 'me';

    get scopeLabel() {
        return this.pathwayScope === 'me' ? 'My accounts' : 'My team';
    }

    get myScopeClass() {
        return this.pathwayScope === 'me' ? 'scope-button active' : 'scope-button';
    }

    get teamScopeClass() {
        return this.pathwayScope === 'team' ? 'scope-button active' : 'scope-button';
    }

    get rows() {
        return PATHWAYS
            .filter((pathway) => pathway.scope === this.pathwayScope)
            .map((pathway) => ({
                ...pathway,
                statusPillClass: pathway.statusClass
            }));
    }

    handleScope(event) {
        this.pathwayScope = event.currentTarget.dataset.scope;
    }
}
