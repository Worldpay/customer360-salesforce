import { LightningElement, api } from 'lwc';
import { NEEDS_ACTION_ITEMS } from 'c/c360MockData_ex_04';

export default class C360NeedsAction_ex_04 extends LightningElement {
    @api title = 'Needs action today';
    @api subtitle = 'Intraday | Daily | Monthly';
    @api items;

    get displayItems() {
        const source = this.items?.length ? this.items : NEEDS_ACTION_ITEMS;
        return source.map((item) => ({
            ...item,
            severityClass: `severity ${item.severity}`,
            buttonClass: item.primary ? 'button accent' : 'button'
        }));
    }

    handleReview(event) {
        const accountName = event.currentTarget.dataset.account;
        this.dispatchEvent(new CustomEvent('accountopen', {
            detail: { accountName },
            bubbles: true,
            composed: true
        }));
    }
}
