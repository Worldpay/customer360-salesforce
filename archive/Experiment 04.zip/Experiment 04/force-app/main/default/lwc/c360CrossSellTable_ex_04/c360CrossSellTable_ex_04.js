import { LightningElement, api } from 'lwc';
import { CROSS_SELL_ROWS } from 'c/c360MockData_ex_04';

export default class C360CrossSellTable_ex_04 extends LightningElement {
    @api title = 'Open cross-sell opportunities';
    @api subtitle = 'Across your portfolio';

    get rows() {
        return CROSS_SELL_ROWS.map((row) => ({
            ...row,
            propensityPillClass: row.propensityClass
        }));
    }

    handleOpenAccount(event) {
        const accountName = event.currentTarget.dataset.account;
        this.dispatchEvent(new CustomEvent('accountopen', {
            detail: { accountName },
            bubbles: true,
            composed: true
        }));
    }
}
