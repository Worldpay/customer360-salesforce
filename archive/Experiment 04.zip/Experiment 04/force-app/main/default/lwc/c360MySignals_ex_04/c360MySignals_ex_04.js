import { LightningElement, api } from 'lwc';
import { SIGNALS } from 'c/c360MockData_ex_04';

export default class C360MySignals_ex_04 extends LightningElement {
    @api title = 'My signals';
    signals = SIGNALS.map((signal) => ({ ...signal }));

    get openSignalCount() {
        return this.signals.filter((signal) => signal.isOpen).length;
    }

    get openCountLabel() {
        return `${this.openSignalCount} open`;
    }

    handleSignalAction(event) {
        this.updateSignal(event.detail, false);
        this.showToast('Signal actioned — pathway created and visible to your manager.');
    }

    handleSignalDismiss(event) {
        this.updateSignal(event.detail, false);
        this.showToast('Signal dismissed.');
    }

    updateSignal(signalId) {
        this.signals = this.signals.map((signal) => (
            signal.id === signalId ? { ...signal, isOpen: false } : signal
        ));
    }

    showToast(message) {
        this.dispatchEvent(new CustomEvent('showtoast', {
            detail: { message },
            bubbles: true,
            composed: true
        }));
    }
}
