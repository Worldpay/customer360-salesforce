import { LightningElement, api } from 'lwc';
import { KPI_TILES } from 'c/c360MockData_ex_04';

export default class C360KpiStrip_ex_04 extends LightningElement {
    @api tiles;

    get displayTiles() {
        const source = this.tiles?.length ? this.tiles : KPI_TILES;
        return source.map((tile) => ({
            ...tile,
            variant: tile.attention ? 'attention' : undefined
        }));
    }
}
